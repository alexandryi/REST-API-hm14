import unittest
from unittest.mock import MagicMock
from sqlalchemy.orm import Session

from src.database.models import Tag, User
from src.schemas import TagModel
from src.repository.tags import get_tags, create_tag, remove_tag


class TestTags(unittest.IsolatedAsyncioTestCase):

    def setUp(self):
        self.session = MagicMock(spec=Session)
        self.user = User(id=1)

    async def test_get_tags(self):
        tags = [Tag(id=1, name="t1"), Tag(id=2, name="t2")]
        self.session.query().filter().all.return_value = tags
        result = await get_tags(user=self.user, db=self.session)
        self.assertEqual(result, tags)

    async def test_create_tag(self):
        body = TagModel(name="tag1")
        tag = Tag(name=body.name, user_id=self.user.id)
        self.session.add.return_value = None
        self.session.commit.return_value = None
        self.session.refresh.return_value = None
        result = await create_tag(body=body, user=self.user, db=self.session)
        self.assertEqual(result.name, "tag1")

    async def test_remove_tag_found(self):
        tag = Tag(id=1, name="tag1", user_id=1)
        self.session.query().filter().first.return_value = tag
        result = await remove_tag(tag_id=1, user=self.user, db=self.session)
        self.assertEqual(result, tag)

    async def test_remove_tag_not_found(self):
        self.session.query().filter().first.return_value = None
        result = await remove_tag(tag_id=1, user=self.user, db=self.session)
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()

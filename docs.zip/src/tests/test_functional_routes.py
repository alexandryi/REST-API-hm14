import pytest
from httpx import AsyncClient
from main import app
from src.database.models import User, Note, Tag

@pytest.mark.asyncio
async def test_create_note(monkeypatch):
    fake_user = User(id=1, email="u@ex.com")
    body = {"title": "test", "description": "desc", "tags": []}

    async def fake_get_current_user():
        return fake_user

    app.dependency_overrides = {}
    app.dependency_overrides[fake_get_current_user] = lambda: fake_user

    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.post("/notes/", json=body)

    assert response.status_code in (200, 201)
    data = response.json()
    assert data["title"] == "test"


@pytest.mark.asyncio
async def test_read_notes(monkeypatch):
    fake_user = User(id=1, email="u@ex.com")

    async def fake_get_current_user():
        return fake_user

    app.dependency_overrides[fake_get_current_user] = lambda: fake_user

    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.get("/notes/")

    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_create_tag(monkeypatch):
    fake_user = User(id=1, email="u@ex.com")
    body = {"name": "tag1"}

    async def fake_get_current_user():
        return fake_user

    app.dependency_overrides[fake_get_current_user] = lambda: fake_user

    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.post("/tags/", json=body)

    assert response.status_code in (200, 201)
    data = response.json()
    assert data["name"] == "tag1"


@pytest.mark.asyncio
async def test_get_user_profile(monkeypatch):
    fake_user = User(id=1, email="u@ex.com")

    async def fake_get_current_user():
        return fake_user

    app.dependency_overrides[fake_get_current_user] = lambda: fake_user

    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.get("/users/me")

    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "u@ex.com"
